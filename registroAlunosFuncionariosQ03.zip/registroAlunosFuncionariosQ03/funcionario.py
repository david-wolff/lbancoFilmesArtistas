
def insereFuncionario(lista):
    print("\n\tInsira os seguintes dados do funcionario a ser inserido no sistema: ")
    nome = str(input("\n\tNome: "))
    codigo = str(input("\n\tCodigo: "))
    cargo = str(input("\n\tCargo: "))
    aluno = []
    aluno.append(nome)
    aluno.append(cargo)
    aluno.append(codigo)
    lista.append(aluno)
    rUser = str(input("\nDeseja registrar mais algum funcionario no sistema?(S/n)"))
    if rUser == 'S':
        insereFuncionario(lista)
    else:
        imprimeListaFuncionarios(lista)
    return
    

def imprimeListaFuncionarios(lista):
    print("\nLista com os funcionarios cadastrados:")
    i = 0
    for item in lista:
        for i in range(0,3):
            if i == 0:
                print("\nFuncionario: ")    
                print("\t" + item[i])
                i += 1
            elif i == 1:
                print("\nCargo: ")    
                print("\t" + item[i])
                i += 1
            elif i == 2:
                print("\nCodigo: ")    
                print("\t" + item[i])
                i += 1
    return


