import aluno
import funcionario

def criaLista():
    lista = []
    return lista

def main():
    listaAlunos = criaLista()
    listaFuncionarios = criaLista()
    aluno.insereAluno(listaAlunos)
    funcionario.insereFuncionario(listaFuncionarios)
    return 
main()