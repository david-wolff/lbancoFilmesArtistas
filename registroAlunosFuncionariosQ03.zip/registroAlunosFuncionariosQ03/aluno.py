def insereAluno(lista):
    print("\n\tInsira os seguintes dados do aluno a ser matriculado: ")
    matricula = str(input("\n\tMatricula: "))
    nome = str(input("\n\tNome: "))
    serie = str(input("\n\tSerie: "))
    aluno = []
    aluno.append(nome)
    aluno.append(matricula)
    aluno.append(serie)
    lista.append(aluno)
    rUser = str(input("\nDeseja mais algum aluno no sistema? (S/n)"))
    if rUser == 'S':
        insereAluno(lista)
    else:
        imprimeListaAlunos(lista)
    return

def imprimeListaAlunos(lista):
    print("\nLista com os alunos matriculados:")
    i = 0
    for item in lista:
        for i in range(0,3):
            if i == 0:
                print("\nAluno: ")    
                print("\t" + item[i])
                i += 1
            elif i == 1:
                print("\nMatricula: ")    
                print("\t" + item[i])
                i += 1
            elif i == 2:
                print("\nCursando: ")    
                print("\t" + item[i])
                i += 1

    return
