#módulo de conexão, inserção e consultas no banco de dados local.

import mysql.connector
from mysql.connector import Error
from xml.etree import *
from xml.etree.ElementTree import *


#Função que cria o banco de dados caso o mesmo não exista. 
def criaBDmySql():
  try:
      connection = mysql.connector.connect(host='localhost',
                                           user='root',
                                           password='banzaiPipeleme_0')
      cursor = connection.cursor()
      cursor.execute("CREATE DATABASE IF NOT EXISTS filmes_artistas;")
      connection.commit()
      print("Base de dados 'filmes_artistas' existe no servidor local.\n")
  except Error as e:
      print("Erro de conexao - criaBDmySql()", e)
      return 0
  finally:
      if(connection.is_connected()):
          cursor.close()
          connection.close()
  return 1

#Função que insere os filmes no banco de dados com as chaves 'nome' e 'codigoIMDB'(PK)
def insereFilmes(nome, codigoIMDB):
  record = (codigoIMDB, nome)

  try:
    connection = mysql.connector.connect(host = 'localhost',
                                         user = 'root',
                                         password = 'banzaiPipeleme_0',
                                         database = 'filmes_artistas')
                          

    cursor = connection.cursor()

    cursor.execute("CREATE TABLE IF NOT EXISTS filmes(codigoIMDB CHAR(32), nome VARCHAR(24), PRIMARY KEY (codigoIMDB));")

    sql = ("""INSERT INTO filmes (codigoIMDB, nome) VALUES (%s, %s);""")

    cursor.execute(sql, record)

    connection.commit()
    print(cursor.rowcount, "Registro Inserido - insereFilmes() ")
    
  except Error as e:
    print("Erro de conexao - insereFilmes()", e)
  
  finally:
    if(connection.is_connected):
      cursor.close()
      connection.close()
      print("Conexao Encerrada. insereFilmes()")  

  return  

#Função que insere os artistas no banco de dados com as chaves 'nome' e 'codigoDRT'(PK)
def insereArtistas(nome, codigoDRT):
  
  record = (codigoDRT, nome)

  try:
    connection = mysql.connector.connect(host='localhost',
                                         user='root',
                                         password='banzaiPipeleme_0',
                                         database='filmes_artistas')
    cursor = connection.cursor()

    cursor.execute("""CREATE TABLE IF NOT EXISTS artistas(codigoDRT VARCHAR(32), nome VARCHAR(24), PRIMARY KEY (codigoDRT))""")
    sql = ("""INSERT INTO artistas (codigoDRT, nome) VALUES (%s, %s);""")
    cursor.execute(sql, record)

    connection.commit()
    print(cursor.rowcount, "Registro Inserido - insereArtistas() ")

  except Error as e:
    print("Erro de conexao - insereArtistas()", e)

  finally:
    if(connection.is_connected()):
      cursor.close()
      connection.close()
      print("Conexao encerrada. - insereArtistas()")
  
  return


#Função que insere os filmes e seus respectivos artistas no banco de dados com as chaves 'codigoDRT'(FK -> artistas(codigoDRT) e 'codigoIMDB'(FK -> filmes(codigoIMDB))
def criaRelacaoArtistasFilmes(codigoIMDB, codigoDRT):

  record = (codigoIMDB, codigoDRT)

  try:
    connection = mysql.connector.connect(host='localhost',
                                         user='root',
                                         password='banzaiPipeleme_0',
                                         database='filmes_artistas')
    cursor = connection.cursor()

    cursor.execute("""CREATE TABLE IF NOT EXISTS participaDe(codigoIMDB CHAR(24), codigoDRT CHAR(32))""")

    sqlQuery = ("""INSERT INTO participaDe(codigoIMDB, codigoDRT) VALUES (%s, %s);""")
    cursor.execute(sqlQuery, record)

    connection.commit()
    print(cursor.rowcount, "Registro Inserido - criaRelacaoArtistasFilmes() ")

  except Error as e:
    print("Erro de conexao - criaRelacaoArtistasFilmes()", e)

  finally:
    if(connection.is_connected()):
      cursor.close()
      connection.close()
      print("Conexao encerrada - criaRelacaoArtistasFilmes()")
  
  return

def imprimeRelacaoFilmesArtistas():

  try:
    connection = mysql.connector.connect(host='localhost',
                                           user='root',
                                           password='banzaiPipeleme_0',
                                           database='filmes_artistas')
    cursor = connection.cursor()
    sqlQuery = ("""SELECT * FROM participaDe;""")
    cursor.execute(sqlQuery)
    participaDe = list(cursor.fetchall())
    sqlQuery = ("""SELECT * FROM filmes;""")
    cursor.execute(sqlQuery)
    filmes = list(cursor.fetchall())
    sqlQuery = ("""SELECT * FROM artistas;""")
    cursor.execute(sqlQuery)
    artistas = list(cursor.fetchall())
    cursor.close()
    
  except Error as e:
    print("Erro de conexao - imprimeRelacaoArtistasFilmes()", e)
    
    #Seguinte query seleciona todos os nomes dos filmes e dos artistas dentro das tabelas 'filmes' e 'artistas' de acordo com as FK's dentro de participaDe.  
 
    cursor.close()
    connection.commit() 
  finally:
    if(connection.is_connected()):
      cursor.close()
      connection.close()
      print("Conexao encerrada - imprimeRelacaoArtistasFilmes()")
  listaPartJuntos = []
  listaElenco = []
  print("\nDigite o codigo DRT de até 3 artistas para verificar suas participações nos filmes listados:")
  artista1 = str(input("Artista 1: "))
  artista2 = str(input("Artista 2: "))
  artista3 = str(input("Artista 3: "))
  
  for linhapd in participaDe:  
    for linhaFilme in filmes:
      if linhaFilme[0] == linhapd[0]:
        for linhaArtista in artistas:
          if linhaArtista[0] == artista1 and linhapd[1] == artista1:
            listaPartJuntos.append(linhaFilme[1])
            if linhaArtista[0] == artista2 and linhapd[1] == artista2 and linhaFilme[1] not in listaPartJuntos:
              listaPartJuntos.append(linhaFilme[1])
              if linhaArtista[0] == artista2 and linhapd[1] == artista3 and linhaFilme[1] not in listaPartJuntos:
                listaPartJuntos.append(linhaFilme[1])

  for filme in listaPartJuntos:
    for linhaFilme in filmes:
      if filme == linhaFilme[1]:
        for linhapd in participaDe:
          if linhapd[0] == linhaFilme[0]:
            for linhaArtista in artistas:
              if linhapd[1] == linhaArtista[0]:
                listaElenco.append(linhaArtista[1])
  print(listaPartJuntos)
  print(listaElenco)
  def criaXmlLista1(lista):
    rootEl = Element("rootFilmes")

    rootEl = SubElement(rootEl, "filmes em comum entre os artistas")


    for item in range(len(lista)):
      filmes_em_comum = SubElement(rootEl, "filme")
      filmes_em_comum.text = str(lista[item])

    tree = ElementTree(rootEl)

    tree.write("filmes_em_comum.xml", encoding = 'utf-8', xml_declaration = True) 
  def criaXmlLista2(lista):
    rootEl = Element("elenco")

    rootEl = SubElement(rootEl, "Elenco")


    for item in range(len(lista)):
      elenco = SubElement(rootEl, "artista")
      elenco.text = str(lista[item])

    tree = ElementTree(rootEl)

    tree.write("elenco_filmes_em_comum.xml", encoding = 'utf-8', xml_declaration = True)     

  criaXmlLista1(listaPartJuntos)
  criaXmlLista2(listaElenco)
  return


##def criaXmlDuasListas(lista1, lista2):
 # rootEl1 = Element("rootEl1")
 # rootEl2 = Element("rootEl2")
#
 # rootEl1 = SubElement(rootEl1, "rootEl1")
 # rootEl2 = SubElement(rootEl2, "rootEl2")
#
 # for item in range(len(lista1)):
 #   i = SubElement(rootEl1, "i")
 #   i.text = str(lista1[item])
#
 # for item in range(len(lista2)):
 #   i = SubElement(rootEl2, "i")
 #   i.text = str(lista2[item])
#
 # tree1 = ElementTree(rootEl1)
 # tree2 = ElementTree(rootEl2)
#
 # tree1.write("Output1.xml", encoding = 'utf-8', xml_declaration = True)      
 # tree2.write("Output2.xml", encoding = 'utf-8', xml_declaration = True)
#
#

